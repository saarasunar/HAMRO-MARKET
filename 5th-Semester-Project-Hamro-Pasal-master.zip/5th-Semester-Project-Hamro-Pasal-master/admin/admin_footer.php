<!-- <footer style="display: flex; justify-content: space-between; align-items: center; padding: 10px; background-color: #000; font-size: 14px; color: #f9f9f9;">
        <p style="margin: 0; text-align: center; flex: 1;">
            &copy; <span id="year"></span> Hamro Pasal | 
            Developed by <a href="https://sakarc.com.np/" target="_blank" style="text-decoration: none; color: #007bff;">Sakar Chaulagain</a>
        </p>
        <a href="tel:+1234567890" style="text-decoration: none; color: #f9f9f9; margin-left: 20px; display: flex; align-items: center;">
            <img src="https://img.icons8.com/ios-filled/24/ffffff/phone.png" alt="Call Icon" style="margin-right: 5px;"> Call Us
        </a>
    </footer>

    <script>
        // Automatically set the current year
        document.getElementById('year').textContent = new Date().getFullYear();
    </script> -->