<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <?php 
        session_start(); 
        include("../conn_db.php"); 
        include('../head.php');
        if($_SESSION["utype"] != "ADMIN"){
            header("location: ../restricted.php");
            exit(1);
        }
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../img/hamro-pasal.png">
    <link href="../css/main.css" rel="stylesheet">
    <title>Customer List | Hamro Pasal</title>
</head>

<body class="d-flex flex-column h-100 bg-light">

    <!-- Navigation Bar -->
    <?php include('nav_header_admin.php') ?>

    <br><br><br><br>
    <div class="container my-4">

        <!-- Notification Messages -->
        <?php if(isset($_GET["up_prf"])): ?>
            <div class="alert alert-<?php echo $_GET["up_prf"] == 1 ? "success" : "danger"; ?> d-flex align-items-center" role="alert">
                <i class="bi <?php echo $_GET["up_prf"] == 1 ? "bi-check-circle-fill" : "bi-x-circle-fill"; ?> me-2"></i>
                <div>
                    <?php echo $_GET["up_prf"] == 1 ? "Successfully updated customer profile." : "Failed to update customer profile."; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Notification Messages account delete -->
<?php if(isset($_GET["del_cst"])): ?>
    <div class="alert alert-<?php echo $_GET["del_cst"] == 1 ? "success" : ($_GET["del_cst"] == "admin" ? "warning" : "danger"); ?> d-flex align-items-center" role="alert">
        <i class="bi <?php echo $_GET["del_cst"] == 1 ? "bi-check-circle-fill" : ($_GET["del_cst"] == "admin" ? "bi-exclamation-circle-fill" : "bi-x-circle-fill"); ?> me-2"></i>
        <div>
            <?php 
            if ($_GET["del_cst"] == 1) {
                echo "Customer account deleted successfully.";
            } elseif ($_GET["del_cst"] == "admin") {
                echo "Admin account cannot be deleted.";
            } else {
                echo "Failed to delete customer account.";
            }
            ?>
        </div>
    </div>
<?php endif; ?>

        <!-- Title -->
        <h2 class="mb-3 display-6"><i class="bi bi-people"></i> Customer List</h2>

        <!-- Search Form -->
        <form method="GET" action="admin_customer_list.php" class="mb-4">
            <div class="row g-2">
                <div class="col-md-3">
                    <input type="text" class="form-control" name="un" placeholder="Username" value="<?php echo $_GET['un'] ?? ''; ?>">
                </div>
                <div class="col-md-3">
                    <input type="text" class="form-control" name="fn" placeholder="First Name" value="<?php echo $_GET['fn'] ?? ''; ?>">
                </div>
                <div class="col-md-3">
                    <input type="text" class="form-control" name="ln" placeholder="Last Name" value="<?php echo $_GET['ln'] ?? ''; ?>">
                </div>
                <div class="col-md-2">
                    <select class="form-select" name="ut">
                        <option value="" selected>Customer Type</option>
                        <option value="CUS" <?php echo ($_GET['ut'] ?? '') == 'CUS' ? 'selected' : ''; ?>>Regular_Customer</option>
                        <option value="ADM" <?php echo ($_GET['ut'] ?? '') == 'ADM' ? 'selected' : ''; ?>>Admin</option>
                       
                    </select>
                </div>
                <div class="col-md-1 d-grid">
                    <button type="submit" name="search" value="1" class="btn btn-success">
                        <i class="bi bi-search"></i> Search
                    </button>
                </div>
            </div>
        </form>

        <!-- Customer Table -->
        <div class="card shadow-sm">
            <div class="card-body">
                <?php
                if (!isset($_GET["search"])) {
                    $search_query = "SELECT c_id, c_username, c_firstname, c_lastname, c_type, c_email FROM customer;";
                } else {
                    $search_un = $_GET["un"];
                    $search_fn = $_GET["fn"];
                    $search_ln = $_GET["ln"];
                    $search_ut = $_GET["ut"];
                    $search_query = "SELECT c_id, c_username, c_firstname, c_lastname, c_type, c_email 
                                     FROM customer 
                                     WHERE c_username LIKE '%$search_un%' 
                                     AND c_firstname LIKE '%$search_fn%' 
                                     AND c_lastname LIKE '%$search_ln%' 
                                     AND c_type LIKE '%$search_ut%';";
                }
                $search_result = $mysqli->query($search_query);
                $search_numrow = $search_result->num_rows;

                if ($search_numrow == 0): ?>
                    <div class="alert alert-warning" role="alert">
                        <i class="bi bi-info-circle-fill"></i> No customer found! 
                        <a href="admin_customer_list.php" class="alert-link">Clear Search</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <caption>
                                <?php echo $search_numrow; ?> customer(s) found. 
                                <?php if (isset($_GET["search"])): ?>
                                    <a href="admin_customer_list.php" class="text-danger">Clear Search Result</a>
                                <?php endif; ?>
                            </caption>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Username</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Type</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; while ($row = $search_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo htmlspecialchars($row["c_username"]); ?></td>
                                        <td><?php echo htmlspecialchars($row["c_firstname"]); ?></td>
                                        <td><?php echo htmlspecialchars($row["c_lastname"]); ?></td>
                                        <td>
                                            <?php 
                                            switch ($row["c_type"]) {
                                                case "CUS": echo "Regular_Customer"; break;
                                                case "ADM": echo "Admin"; break;
                                                
                                            }
                                            ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($row["c_email"]); ?></td>
                                        <td>
                                            <a href="admin_customer_detail.php?c_id=<?php echo $row["c_id"]; ?>" class="btn btn-sm btn-primary">
                                                <i class="bi bi-eye"></i> View
                                            </a>
                                            <a href="admin_customer_edit.php?c_id=<?php echo $row["c_id"]; ?>" class="btn btn-sm btn-outline-success">
                                                <i class="bi bi-pencil"></i> Edit
                                            </a>
                                            <a href="admin_customer_delete.php?c_id=<?php echo $row["c_id"]; ?>" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif;
                $search_result->free_result();
                ?>
            </div>
        </div>
    </div>
                                        
    <!-- Footer -->
    <?php include('admin_footer.php'); ?>
</body>

</html>
